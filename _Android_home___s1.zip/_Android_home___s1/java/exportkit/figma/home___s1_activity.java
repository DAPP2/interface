
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		home___s1
	 *	@date 		Monday 29th of May 2023 04:17:04 PM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class home___s1_activity extends Activity {

	
	private View _bg__home___s1_ek2;
	private TextView saf;
	private TextView acex;
	private TextView skem;
	private TextView chem;
	private TextView rsm;
	private TextView eee;
	private TextView powered_by_imperial;
	private ImageView vector;
	private ImageView city_buildings;
	private ImageView vector_ek1;
	private TextView which_building_do_you_want_to_go_to_;
	private TextView navi;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.home___s1);

		
		_bg__home___s1_ek2 = (View) findViewById(R.id._bg__home___s1_ek2);
		saf = (TextView) findViewById(R.id.saf);
		acex = (TextView) findViewById(R.id.acex);
		skem = (TextView) findViewById(R.id.skem);
		chem = (TextView) findViewById(R.id.chem);
		rsm = (TextView) findViewById(R.id.rsm);
		eee = (TextView) findViewById(R.id.eee);
		powered_by_imperial = (TextView) findViewById(R.id.powered_by_imperial);
		vector = (ImageView) findViewById(R.id.vector);
		city_buildings = (ImageView) findViewById(R.id.city_buildings);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		which_building_do_you_want_to_go_to_ = (TextView) findViewById(R.id.which_building_do_you_want_to_go_to_);
		navi = (TextView) findViewById(R.id.navi);
	
		
		//custom code goes here
	
	}
}
	
	